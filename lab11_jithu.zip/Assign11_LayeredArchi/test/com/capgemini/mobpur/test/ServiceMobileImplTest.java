package com.capgemini.mobpur.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.mobpur.bean.MobileBean;
import com.capgemini.mobpur.exception.MobilePurchaseException;
import com.capgemini.mobpur.service.IServiceMobile;
import com.capgemini.mobpur.service.ServiceMobileImpl;

public class ServiceMobileImplTest {
	
	private IServiceMobile serviceMobile;
	@Before
	public void setUp() throws Exception {
		serviceMobile = new ServiceMobileImpl();
	}

	@After
	public void tearDown() throws Exception {
		serviceMobile = null;
	}

	@Test
	public final void testSearch() {
		try {
			List<MobileBean>mobileList = serviceMobile.search(15000,38000);
			assertTrue("No such mobile",mobileList.size()>0);
			
		} catch (MobilePurchaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
