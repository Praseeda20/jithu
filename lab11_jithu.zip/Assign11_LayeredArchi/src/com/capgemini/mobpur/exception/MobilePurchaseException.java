package com.capgemini.mobpur.exception;

public class MobilePurchaseException extends Exception {

	//Put mouse arrow on MobilePurchaseExcepion and select serialID option
	private static final long serialVersionUID = -4379705644635273194L;

	/**
	 * 
	 */
	
	// Generate Contructors from superclass of "Exception(Throwable)"
	public MobilePurchaseException(){
		super();
	}

	public MobilePurchaseException(String message) {
		super(message);
	}


}
