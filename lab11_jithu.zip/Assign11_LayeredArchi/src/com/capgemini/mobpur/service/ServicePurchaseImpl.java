package com.capgemini.mobpur.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.mobpur.bean.PurchaseDetailsBean;
import com.capgemini.mobpur.dao.IMobileDAO;
import com.capgemini.mobpur.dao.IPurchaseDetailsDAO;
import com.capgemini.mobpur.dao.MobileDAOImpl;
import com.capgemini.mobpur.dao.PurchaseDetailsDAOImpl;
import com.capgemini.mobpur.exception.MobilePurchaseException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws MobilePurchaseException {

		int mobileQuantity = 0;
		boolean isItInserted = false;
		boolean isUpdated = false;
		
		IPurchaseDetailsDAO purchaseDetailsDAO = new PurchaseDetailsDAOImpl();
		IMobileDAO mobileDAO = new MobileDAOImpl();
		
		mobileQuantity = mobileDAO.getQuantity(purchaseDetailsBean.getMobileId());
		
		if(mobileQuantity > 0){
			isItInserted = purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
		
			//isItInserted = purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
			mobileQuantity--;
			isUpdated = mobileDAO.updateMobile(purchaseDetailsBean.getMobileId(), mobileQuantity);
		}
		return isItInserted && isUpdated;
	}
	
	public boolean isValidCName(String cname) throws MobilePurchaseException{
		boolean isValid = false;
		
		String pattern = "[A-Z][A-Za-z]{2,19}";
		Pattern pt = Pattern.compile(pattern);
		Matcher matcher = pt.matcher(cname);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new MobilePurchaseException("Invalid name");
		}
		return isValid;
	}
	
	public boolean isValidPhoneNo(String phoneNo) throws MobilePurchaseException{
		boolean isValid = false;
		
		String pattern = "[\\d]{10}";
		Pattern pt = Pattern.compile(pattern);
		Matcher matcher = pt.matcher(phoneNo);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new MobilePurchaseException("Invalid Phone No.");
		}
		return isValid;
	}
	
	public boolean isValidMail(String emailId)throws MobilePurchaseException{
		boolean isValid = false;
		
		String pattern = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";
		Pattern pt = Pattern.compile(pattern);
		Matcher matcher = pt.matcher(emailId);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new MobilePurchaseException("Invalid Email ID");
		}
		return isValid;
	}
	
	public boolean isValidMobileId(int mobileId) throws MobilePurchaseException{
		boolean isValid = false;
		
		String mobile = Integer.toString(mobileId);
		
		String pattern = "[\\d]{4}";
		Pattern pt = Pattern.compile(pattern);
		Matcher matcher = pt.matcher(mobile);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new MobilePurchaseException("Invalid Mobile ID.");
		}
		return isValid;
	}
}
